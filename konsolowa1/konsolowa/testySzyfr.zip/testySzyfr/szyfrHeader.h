#include "source.cpp"
string szyfruj(string, int);
void danePodstawowe();
void zawijanie();
void odszyfrowanie();
void dlugiKlucz();
void Spacja();
